# Código do projeto

> Aqui devem ficar os arquivos-fonte do projeto: HTML, CSS, JavaScript, imagens e outros necessários para o funcionamento do sistema.

[Código do front-end](../src/front) -- repositório do código do front-end

[Código do back-end](../src/back)  -- repositório do código do back-end

[Scripts SQL](../src/db)  -- repositório dos scripts SQL

> **Links úteis**:
> - [Instruções sobre acesso a APIs externas](https://github.com/ICEI-PUC-Minas-PMV-SI/WebApplicationProject-Template/blob/main/help/apis.md)


## Instalação do Site

É necessário implantá-lo em um servidor web de sua preferência. Existem diversos servidores web gratuitos que podem ser utilizados, tal como GitHub Pages (GitHub.IO), Vercel, Render, Netlify, Surge.sh, entre outros. [Insira o endereço eletrônico público para acessá-lo.] 

## Histórico de versões

### [0.1.0] - DD/MM/AAAA
#### Adicionado/Atualizado/Removido
- Relação de artefatos ... 
