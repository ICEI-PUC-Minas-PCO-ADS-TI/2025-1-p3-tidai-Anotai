function enviarPlaylist() {
  const nome = document.querySelector('[name="nome-playlist"]').value;
  const descricao = document.querySelector('[name="descricao"]').value;
  const categoria = document.querySelector('#categoria-lista .cat-tag.selecionado')?.textContent.trim() || '';
  const tag = document.querySelector('#tags-lista .cat-tag.selecionado')?.textContent.trim() || '';
  const prioridade = document.querySelector('.button-p button.selecionado')?.textContent.trim().toLowerCase() || '';
  const dataConclusao = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const token = localStorage.getItem('token');

  const dados = {
    nome_playlist: nome,
    descricao_playlist: descricao,
    categoria_playlist: categoria,
    tag_playlist: tag,
    prioridade,
    data_conclusao: parseInt(dataConclusao)
  };

  fetch('http://localhost:3000/playlists', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(dados)
  })
    .then(res => res.json())
    .then(res => {
      alert(res.mensagem || 'Erro ao criar playlist');
    })
    .catch(() => {
      alert('Erro ao conectar com o servidor.');
    });
}

// Evento do botão "Publicar"
document.querySelector('.submit.publicar').addEventListener('click', () => {
  enviarPlaylist();
});

// Seleção de prioridade
document.querySelectorAll('.button-p button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.button-p button').forEach(b => b.classList.remove('selecionado'));
    btn.classList.add('selecionado');
  });
});

//CATEGORIA E TAGS

console.log("JS carregado corretamente");

document.addEventListener('DOMContentLoaded', () => {
  function ativarSelecao(containerId) {
    const container = document.getElementById(containerId);
    const itens = container.querySelectorAll('.cat-tag');

    itens.forEach(item => {
      item.addEventListener('click', () => {
        itens.forEach(el => el.classList.remove('selecionado'));
        item.classList.add('selecionado');
        console.log(`Selecionado: ${item.textContent}`);
      });
    });
  }

  ativarSelecao('categoria-lista');
  ativarSelecao('tags-lista');
});