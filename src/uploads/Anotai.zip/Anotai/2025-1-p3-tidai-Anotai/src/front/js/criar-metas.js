document.addEventListener('DOMContentLoaded', function () {
  const token = localStorage.getItem('token');
  const id_playlist = localStorage.getItem('id_playlist');

  const prioridadeContainer = document.getElementById('prioridade-lista');
  const prioridadeTags = prioridadeContainer.querySelectorAll('.cat-tag');
  let prioridadeSelecionada = '';

  prioridadeTags.forEach(tag => {
    tag.addEventListener('click', () => {
      prioridadeTags.forEach(t => t.classList.remove('selecionado'));
      tag.classList.add('selecionado');
      prioridadeSelecionada = tag.textContent.trim().toLowerCase();
    });
  });

  const botao = document.querySelector('#btn-metas button');
  botao.addEventListener('click', async function () {
    const formData = new FormData();
    formData.append('id_playlist', id_playlist);
    formData.append('nome_meta', document.querySelector('[name="nome-playlist"]').value);
    formData.append('descricao_meta', document.querySelector('[name="descricao"]').value);
    formData.append('prioridade_meta', prioridadeSelecionada);

    const imagem = document.getElementById('upload-foto').files[0];
    if (imagem) formData.append('imagem_meta', imagem);

    const arquivos = document.getElementById('upload-arquivos').files;
    for (let i = 0; i < arquivos.length; i++) {
      formData.append('arquivos', arquivos[i]);
    }

    try {
      const response = await fetch('/metas', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });

      if (response.ok) {
        alert('Meta criada com sucesso!');
        window.location.href = 'criar-playlists.html';
      } else {
        const erro = await response.json();
        alert(`Erro: ${erro.mensagem}`);
      }
    } catch (err) {
      alert(`Erro ao enviar meta: ${err.message}`);
    }
  });
});